from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import hashlib
import winsound
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
screenWidth = 0
screenHeight = 0
standardGeometry = "700x380+"

def login(username):
    if username == "admin":
        showAdminPanel()
    else:
        showUserPanel(username)

def showAdminPanel():
    def quitButton():
        nonlocal adminPanel
        quitConfirm = messagebox.askyesno(title=None,message="Are you sure you want to quit?")
        if  quitConfirm == True:
            adminPanel.destroy()
        else:
            return    
    adminPanel = Tk()
    adminPanel.configure(bg="white")
    adminPanel.resizable(False, False)
    adminPanel.overrideredirect(1)
    adminPanel.geometry(standardGeometry)
    label1 = Label(adminPanel, bg="white", text="Admin control panel", font=('Calibri', 14))
    btnQuestions = Button(adminPanel, width=30, bg="black", fg="white", text="View/Edit Questions", font=('System', 16), command=lambda:[adminPanel.destroy(), editQuestions()])
    btnUsers = Button(adminPanel, width=30, bg="black", fg="white", text="View/Edit Users", font=('System', 16), command=lambda:[adminPanel.destroy, editUsers()])
    btnLogout = Button(adminPanel, width=30, bg="black", fg="white", text="Logout", font=('System', 16), command=lambda:[adminPanel.destroy(), showLogin()])
    btnExit = Button(adminPanel,width=2, bg="black", fg="white", text="X", font=('System', 14), command=quitButton)
    btnExit.pack(pady=(0,0), padx=(650,0))
    label1.pack(pady=(0,0))
    btnQuestions.pack(pady=(10,0))
    btnUsers.pack(pady=(10,0))
    btnLogout.pack(pady=(10,0))  


def editQuestions():
    def loadQuestion(index):
        nonlocal questions
        nonlocal question
        nonlocal answers
        question.delete(1.0, END)
        question.insert(END, questions[index][0])
        for x in range (0,4):
            answers[x].delete(1.0, END)
            answers[x].insert(END, questions[index][x+1])
    def previousQuestion():
        nonlocal index
        nonlocal isNewQuestion
        if index > 0:
            if isNewQuestion:
                del questions[index]
            index -= 1
            loadQuestion(index)
            isNewQuestion = False
        else:
            winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS | winsound.SND_ASYNC)
    def nextQuestion():
        nonlocal index
        nonlocal isNewQuestion
        print (isNewQuestion)
        if len(questions) > (index+1):
            index += 1
            loadQuestion(index)
        else:
            if isNewQuestion is False:
                 index += 1
                 createNewQuestion()
            else:
                winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS | winsound.SND_ASYNC)
    def saveQuestionFile():
        nonlocal questionFile
        nonlocal questions
        nonlocal question
        nonlocal answers
        nonlocal index
        nonlocal isNewQuestion
        if questions[index] != (question.get("1.0", "end-1c"), answers[0].get("1.0", "end-1c"), answers[1].get("1.0", "end-1c"), answers[2].get("1.0", "end-1c"), answers[3].get("1.0", "end-1c")):
            print("UNTRUE")
            print (questions[index])
            print ((question.get("1.0", "end-1c"), answers[0].get("1.0", "end-1c"), answers[1].get("1.0", "end-1c"), answers[2].get("1.0", "end-1c"), answers[3].get("1.0", "end-1c")))
            questions[index] = (question.get("1.0", "end-1c"), answers[0].get("1.0", "end-1c"), answers[1].get("1.0", "end-1c"), answers[2].get("1.0", "end-1c"), answers[3].get("1.0", "end"))
        questionFile.seek(0)
        fileContents = ""
        for x in range (0, len(questions)):
            fileContents += "{0}|{1}|{2}|{3}|{4}\n".format(questions[x][0].rstrip(),questions[x][1].rstrip(),questions[x][2].rstrip(),questions[x][3].rstrip(),questions[x][4].rstrip())
        questionFile.truncate(0)    
        questionFile.write(fileContents)
        isNewQuestion = False
    def deleteQuestion():
        nonlocal isNewQuestion
        nonlocal questions
        nonlocal index
        print(len(questions))
        if len(questions) == 1:
            messagebox.showerror(message="You can't delete all the questions!")
            return
        if isNewQuestion is True:
            messagebox.showerror(message="You can't delete a question you haven't saved!")
        else:
            del questions[index]
            print(len(questions))
            if index >= len(questions):
                index -= 1
            loadQuestion(index)
            saveQuestionFile()
    def createNewQuestion():
        nonlocal questions
        nonlocal isNewQuestion
        isNewQuestion = True
        questions.append((("New question").rstrip(), ("Correct answer").rstrip(), ("Wrong answer 1").rstrip(), ("Wrong answer 2").rstrip(), ("Wrong answer 3").rstrip()))
        loadQuestion(-1)
    def quitButton():
        nonlocal questionEdit
        quitConfirm = messagebox.askyesno(title=None,message="Are you sure you want to quit?")
        if  quitConfirm == True:
            questionFile.close()
            questionEdit.destroy()
        else:
            return
        
        
    isNewQuestion = False    
    questions = [] # This list contains tuples in the format (Question, correct answer, wrong answer 1, wrong answer 2, wrong answer 3)
    index = 0 # The index of the currently viewed question
    questionEdit = Tk()
    frame = []
    for x in range (0,6):
        frame.append(Frame(questionEdit, borderwidth=0, highlightthickness = 0, bg="white"))
    questionEdit.configure(bg="white")
    questionEdit.resizable(False, False)
    questionEdit.overrideredirect(1)
    questionEdit.geometry(standardGeometry)
    label1 = Label(questionEdit, bg="white", text="Question editor", font=('Calibri', 14))
    questionFile = open("questions.txt", "r+")
    lineNo = 0
    for line in questionFile:
        readQuestion = line.split('|')
        questions.append (tuple(readQuestion)) 
        lineNo += 1
    label2 = Label(frame[0], bg="white", text="Question:",  font=('Calibri',16))
    label3 = Label(frame[1], bg="white", text="Correct answer:",  font=('Calibri',16))
    label4 = Label(frame[2], bg="white", text="Wrong answer 1:",  font=('Calibri',16))
    label5 = Label(frame[3], bg="white", text="Wrong answer 2:",  font=('Calibri',16))
    label6 = Label(frame[4], bg="white", text="Wrong answer 3:",  font=('Calibri',16))
    btnExit = Button(questionEdit,width=2, bg="black", fg="white", text="X", font=('System', 14), command=quitButton)
    btnPrev = Button(frame[5],width=2, bg="black", fg="white", text="<<", font=('System', 14), command=previousQuestion)
    btnNext = Button(frame[5],width=2, bg="black", fg="white", text=">>", font=('System', 14), command=nextQuestion)
    btnSave = Button(frame[5],width=8, bg="black", fg="white", text="Save", font=('System', 14), command=saveQuestionFile)
    btnDelete = Button(frame[5],width=8, bg="black", fg="white", text="Delete", font=('System', 14), command=deleteQuestion)
    question = Text(frame[0], height = 2, width = 45)
    answers = [None]*4
    answers[0] = Text(frame[1], height = 1, width = 45)
    answers[1] = Text(frame[2], height = 1, width = 45)
    answers[2] = Text(frame[3], height = 1, width = 45)
    answers[3] = Text(frame[4], height = 1, width = 45)
    loadQuestion(0)
    btnExit.pack(padx=(650,0), pady=(5,0))
    label1.pack(pady=(0,10))
    label2.pack(side=LEFT)
    question.pack(side=LEFT)
    frame[0].pack(side=TOP, anchor=N, pady=(0,30))
    label3.pack(side=LEFT)
    answers[0].pack(side=LEFT, padx=(12))
    frame[1].pack(side=TOP, anchor=NW, pady=(0,20))
    label4.pack(side=LEFT)
    answers[1].pack(side=LEFT)
    frame[2].pack(side=TOP, anchor=NW, pady=(0,20))
    label5.pack(side=LEFT)
    answers[2].pack(side=LEFT)
    frame[3].pack(side=TOP, anchor=NW, pady=(0,20))
    label6.pack(side=LEFT)
    answers[3].pack(side=LEFT)
    frame[4].pack(side=TOP, anchor=NW, pady=(0,20))
    btnPrev.pack(side=LEFT, anchor=W, padx=(0,0))
    btnDelete.pack(side=LEFT, anchor=S, padx=(0,0))
    btnSave.pack(side=LEFT, anchor=S, padx=(0,0))
    btnNext.pack(side=LEFT,anchor=E, padx=(0,0))
    frame[5].pack(side=BOTTOM)
    questionEdit.mainloop()
    
def showUserPanel(username):
    doNothing()


def showLogin():
    def quitButton():
        nonlocal window
        quitConfirm = messagebox.askyesno(title=None,message="Are you sure you want to quit?")
        if  quitConfirm == True:
            window.destroy()
        else:
            return    
    global screenWidth
    global screenHeight
    global standardGeometry
    window = Tk()
    if screenWidth == 0 or screenHeight == 0: # Gets screen dimensions and sets the appropriate position for the window if not yet set
        screenWidth = window.winfo_screenwidth()
        screenHeight = window.winfo_screenheight()
        standardGeometry += str(int(screenWidth/2 - 350)) + '+' + str(int(screenHeight/2 - 190))
    window.configure(bg="white")
    window.resizable(False, False)
    window.overrideredirect(1)
    window.wm_attributes("-topmost", 1)
    window.geometry(standardGeometry) #Window size and position, ("Widthxheight + xpos + ypos"), in pixels
    label1 = Label(window, bg="white", text="Please enter your details", font=('Calibri', 20))
    label2 = Label(window, bg="white", text="Email address:", font=('Calibri', 16))
    label3 = Label(window, bg="white", text="Password:", font=('Calibri', 16))
    btnExit = Button(window, width=2, bg="black", fg="white", text="X", font=('System', 14), command=quitButton) 
    btnBegin = Button(window, width=15, bg="black", fg="white", text="Begin", font=('Calibri', 20), command= lambda: submitButton(window))
    email = Entry(window, relief="raised", borderwidth=2, width=36, font=('Calibri', 18))
    password = Entry(window, relief="raised", borderwidth=2, show="*",  width=36, font=('Calibri', 18))
    btnExit.pack(pady=(0,0), padx=(650,0))
    label1.pack(pady=(15,0))
    label2.pack(anchor=W, padx=55, pady=(25,0))
    email.pack(pady=(0,20))
    label3.pack(anchor=W, padx=55, pady=(0,0))
    password.pack(pady=0)
    btnBegin.pack(pady=30)
    window.mainloop()

def submitButton(window):
    users = {} # The dictionary to contain (username: password) entries
    windowWidgets = window.winfo_children()
    username = windowWidgets[5].get()
    password = windowWidgets[6].get()
    hashedPassword = hashlib.sha256(str.encode(password))
    userfile = open("users.txt", 'r')
    for line in userfile:
        users[line.split()[0]] = line.split()[1]
    if username in users:
        print(users[username])
        if hashedPassword.hexdigest() == users[username]:
            window.destroy()
            login(username)
        else:
            messagebox.showerror(title="Error", message="Invalid username or password,")
    else:
        messagebox.showerror(title="Error", message="Invalid username or password,")
    
def showPolicy():
    def acceptButton():
        policyWindow.destroy()
        showLogin()
    policyWindow = Tk()
    policyWindow.title("Recruitment")
    policyFrame = ttk.Frame(policyWindow)
    policyDoc = PhotoImage(file="RecruitmentPolicies.gif")
    policyBox = Label(image=policyDoc)  
    openingText = Label(text="Please read and agree to abide by our policy document before continuing:")
    openingText.pack()
    policyBox.pack()
    btnAccept = Button(text="I acknowledge and agree to abide by this policy", command=acceptButton)
    btnAccept.pack()
    policyWindow.mainloop()
    
showPolicy()
